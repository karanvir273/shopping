-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2024 at 10:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digital_media_collection`
--

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `product_id`) VALUES
(6, 3, 2),
(7, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `director` varchar(255) NOT NULL,
  `writer` varchar(255) NOT NULL,
  `stars` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `details`, `price`, `image`, `created_at`, `director`, `writer`, `stars`) VALUES
(1, 'Premium Yoga Mat', 'Our Premium Yoga Mat is designed for ultimate comfort and stability. Made from high-density, eco-friendly materials, this mat provides a non-slip surface and excellent cushioning to support your yoga practice.', 'Dimensions: 72” x 24” x 0.25”\\nMaterial: Eco-friendly TPE\\nColors: Available in blue, green, and purple\\nFeatures: Non-slip surface, extra cushioning, easy to clean\', 45.99, \'yoga-mat.jpg\')', 199.99, 'dumbbells.jpg', '2024-08-11 08:36:43', '', '', ''),
(2, 'Premium Yoga Mat', 'Our Premium Yoga Mat is designed for ultimate comfort and stability. Made from high-density, eco-friendly materials, this mat provides a non-slip surface and excellent cushioning to support your yoga practice.', '', 45.99, 'https://via.placeholder.com/600x180?text=Premium+Yoga+Mat', '2024-08-11 18:28:14', '', '', ''),
(3, 'Adjustable Dumbbells', 'These Adjustable Dumbbells are perfect for a versatile home workout. Easily adjust the weight from 5 lbs to 52.5 lbs with a simple dial mechanism, making them ideal for both beginners and advanced users.', '', 199.99, 'https://via.placeholder.com/600x180?text=Adjustable+Dumbbells', '2024-08-11 18:28:14', '', '', ''),
(4, 'Resistance Bands Set', 'Enhance your workouts with our Resistance Bands Set, which includes five different resistance levels to accommodate various exercises. These bands are made from high-quality latex, ensuring durability and elasticity.', '', 29.99, 'https://via.placeholder.com/600x180?text=Resistance+Bands+Set', '2024-08-11 18:28:14', '', '', ''),
(5, 'High-Performance Protein Powder', 'Fuel your workouts with our High-Performance Protein Powder. Formulated with 24g of protein per serving, it supports muscle recovery and growth. Available in delicious chocolate and vanilla flavors.', '', 39.99, 'https://via.placeholder.com/600x180?text=Protein+Powder', '2024-08-11 18:28:14', '', '', ''),
(6, 'Stainless Steel Water Bottle', 'Stay hydrated with our Stainless Steel Water Bottle. This 750ml bottle keeps your drinks cold for up to 24 hours or hot for up to 12 hours, making it perfect for workouts and daily use.', '', 19.99, 'https://via.placeholder.com/600x180?text=Stainless+Steel+Water+Bottle', '2024-08-11 18:28:14', '', '', ''),
(7, 'Gym Gloves', 'Protect your hands and enhance your grip with our durable Gym Gloves. These gloves are made with breathable material and padded palms for maximum comfort during weight lifting.', '', 14.99, 'https://via.placeholder.com/600x180?text=Gym+Gloves', '2024-08-11 18:28:14', '', '', ''),
(8, 'Foam Roller', 'Aid your recovery with our high-density Foam Roller. Perfect for self-myofascial release, this roller helps to reduce muscle tightness, improve mobility, and increase blood flow.', '', 24.99, 'https://via.placeholder.com/600x180?text=Foam+Roller', '2024-08-11 18:28:14', '', '', ''),
(9, 'Smart Fitness Watch', 'Track your fitness progress with our Smart Fitness Watch. Featuring heart rate monitoring, step tracking, and sleep analysis, this watch helps you stay on top of your health goals.', '', 59.99, 'https://via.placeholder.com/600x180?text=Smart+Fitness+Watch', '2024-08-11 18:28:14', '', '', ''),
(10, 'Treadmill', 'Experience a professional-grade workout at home with our high-performance Treadmill. Featuring multiple speed settings, incline options, and a built-in display for tracking your progress, this treadmill is perfect for all fitness levels.', '', 799.99, 'https://via.placeholder.com/600x180?text=Treadmill', '2024-08-11 18:28:14', '', '', ''),
(11, 'Exercise Bike', 'Our Exercise Bike offers a low-impact cardiovascular workout. It features adjustable resistance levels, a comfortable seat, and a digital monitor to keep track of your workout stats.', '', 299.99, 'https://via.placeholder.com/600x180?text=Exercise+Bike', '2024-08-11 18:28:14', '', '', ''),
(12, 'Kettlebell Set', 'Build strength and endurance with our Kettlebell Set. Each kettlebell is designed with a wide, comfortable handle for a secure grip, and is color-coded for easy weight identification.', '', 89.99, 'https://via.placeholder.com/600x180?text=Kettlebell+Set', '2024-08-11 18:28:14', '', '', ''),
(13, 'Ab Roller Wheel', 'Strengthen your core with our Ab Roller Wheel. This simple yet effective tool targets your abs, shoulders, and back muscles, providing a challenging and efficient workout.', '', 19.99, 'https://via.placeholder.com/600x180?text=Ab+Roller+Wheel', '2024-08-11 18:28:14', '', '', ''),
(14, 'Jump Rope', 'Improve your cardiovascular health and coordination with our high-speed Jump Rope. Adjustable length and ergonomic handles make this jump rope perfect for all fitness levels.', '', 14.99, 'https://via.placeholder.com/600x180?text=Jump+Rope', '2024-08-11 18:28:14', '', '', ''),
(15, 'Medicine Ball', 'Enhance your strength and conditioning routines with our versatile Medicine Ball. Ideal for a wide range of exercises, including core work, plyometrics, and balance training.', '', 29.99, 'https://via.placeholder.com/600x180?text=Medicine+Ball', '2024-08-11 18:28:14', '', '', ''),
(16, 'Weightlifting Belt', 'Support your lower back during heavy lifts with our durable Weightlifting Belt. Made from high-quality leather, this belt provides the stability and support needed for safe and effective lifting.', '', 49.99, 'https://via.placeholder.com/600x180?text=Weightlifting+Belt', '2024-08-11 18:28:14', '', '', ''),
(17, 'Pull-Up Bar', 'Install our versatile Pull-Up Bar in your home for a complete upper body workout. This bar is easy to install and can be used for pull-ups, chin-ups, and other bodyweight exercises.', '', 39.99, 'https://via.placeholder.com/600x180?text=Pull-Up+Bar', '2024-08-11 18:28:14', '', '', ''),
(18, 'Gym Bag', 'Carry all your workout essentials in style with our durable and spacious Gym Bag. Featuring multiple compartments, this bag keeps your gear organized and easily accessible.', '', 34.99, 'https://via.placeholder.com/600x180?text=Gym+Bag', '2024-08-11 18:28:14', '', '', ''),
(19, 'Massage Gun', 'Accelerate muscle recovery with our high-performance Massage Gun. This device offers deep tissue massage with adjustable speeds and interchangeable heads to target specific muscle groups.', '', 129.99, 'https://via.placeholder.com/600x180?text=Massage+Gun', '2024-08-11 18:28:14', '', '', ''),
(20, 'Fitness Tracker', 'Monitor your health and fitness progress with our advanced Fitness Tracker. Features include heart rate monitoring, sleep tracking, and step counting, all displayed on an easy-to-read screen.', '', 49.99, 'https://via.placeholder.com/600x180?text=Fitness+Tracker', '2024-08-11 18:28:14', '', '', ''),
(21, 'Foam Plyo Box', 'Improve your explosive power and agility with our Foam Plyo Box. Made with high-density foam, this box provides a safe and stable platform for plyometric exercises.', '', 99.99, 'https://via.placeholder.com/600x180?text=Foam+Plyo+Box', '2024-08-11 18:28:14', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `product_id`, `rating`, `comment`, `created_at`) VALUES
(2, 'vbcbcv', 1, 4, 'ghg', '2024-08-11 19:39:41'),
(3, 'dgre', 1, 5, 'dgdf', '2024-08-11 19:39:55'),
(4, 'ads', 1, 3, 'asdas', '2024-08-11 19:57:10'),
(5, 'werwe', 2, 3, 'werew', '2024-08-11 20:02:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(3, 'test@gmail.com', 'test@gmail.com', '$2y$10$qFc71wRc4QCBmR6ubx7FPOhx0Ez2dfJib/h10Spmu4Rqh/utCtslC', '2024-08-11 13:38:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

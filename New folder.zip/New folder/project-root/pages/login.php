<?php
session_start();
include '../includes/db.php'; // Adjust the path if necessary

// Get the database connection
$conn = getDB();

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Prepare the SQL statement
    $stmt = $conn->prepare('SELECT id, password FROM users WHERE email = ?');

    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param('s', $email);

    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }

    // Bind result variables
    $stmt->store_result();
    $stmt->bind_result($userId, $hashedPassword);

    // Check if a row was returned
    if ($stmt->num_rows === 1) {
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['user_id'] = $userId;
            header('Location: user-account.php');
            exit();
        } else {
            $error = 'Invalid credentials.';
        }
    } else {
        $error = 'No user found with this email.';
    }

    // Close the statement
    $stmt->close();

    // Close the connection
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css"> <!-- Link to your custom CSS -->
</head>

<body>
    <?php include '../includes/partials/header.php'; // Ensure your header includes session handling 
    ?>
    <div class="container mt-4">
        <h2>Login</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>
    <?php include '../includes/partials/footer.php'; // Ensure your header includes session handling 
    ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
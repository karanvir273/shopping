<?php
session_start();
include '../includes/db.php'; // Ensure this file contains your database connection

// Get the database connection
$conn = getDB(); // Replace with the appropriate function or connection method

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // If user is not logged in, redirect to login page with a message
    header("Location: login.php?message=Please log in to add or remove favorites.");
    exit();
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Get product ID from the request
if (!isset($_GET['id'])) {
    die('Product ID not specified.');
}
$product_id = (int)$_GET['id'];

// Check if the product is already a favorite
$check_query = $conn->prepare("SELECT * FROM favorites WHERE user_id = ? AND product_id = ?");
$check_query->bind_param("ii", $user_id, $product_id);
$check_query->execute();
$exists = $check_query->get_result()->num_rows > 0;

// Insert or delete favorite based on current status
if ($exists) {
    // Remove from favorites
    $delete_query = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND product_id = ?");
    $delete_query->bind_param("ii", $user_id, $product_id);
    $delete_query->execute();
} else {
    // Add to favorites
    $insert_query = $conn->prepare("INSERT INTO favorites (user_id, product_id) VALUES (?, ?)");
    $insert_query->bind_param("ii", $user_id, $product_id);
    $insert_query->execute();
}

// Redirect back to the previous page
header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
?>

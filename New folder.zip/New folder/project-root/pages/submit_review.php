<?php
session_start();
include '../includes/db.php'; // Ensure this file contains your database connection

// Get the database connection
$conn = getDB(); // Replace with the appropriate function or connection method

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $user_id = $_POST['user_id'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO reviews (product_id, user_id, rating, comment, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("isis", $product_id, $user_id, $rating, $comment);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect back to shopping page or send success response
        header('Location: shopping.php');
        exit();
    } else {
        echo 'Error: ' . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

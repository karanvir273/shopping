<?php
include '../includes/db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('Invalid Product ID');
}

$product_id = intval($_GET['id']);
$db = getDB();
$query = "SELECT * FROM products WHERE id = ?";
$stmt = $db->prepare($query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    die('Product not found');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php include '../includes/partials/header.php'; ?>
    <div class="container mt-4">
        <h1 class="text-center mb-4"><?php echo htmlspecialchars($product['title'] ?? 'Product Title Not Available'); ?></h1>

        <div class="row">
            <div class="col-md-6">
                <img src="../images/<?php echo htmlspecialchars($product['image'] ?? 'default.jpg'); ?>" class="img-fluid" alt="<?php echo htmlspecialchars($product['title'] ?? 'Product Image'); ?>">
            </div>
            <div class="col-md-6">
                <h2>$<?php echo number_format($product['price'] ?? 0, 2); ?></h2>
                <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($product['description'] ?? 'Description Not Available')); ?></p>
                <p><strong>Details:</strong> <?php echo nl2br(htmlspecialchars($product['details'] ?? 'Details Not Available')); ?></p>
                <p><strong>Director:</strong> <?php echo htmlspecialchars($product['director'] ?? 'Director Not Available'); ?></p>
                <p><strong>Writer:</strong> <?php echo htmlspecialchars($product['writer'] ?? 'Writer Not Available'); ?></p>
                <p><strong>Stars:</strong> <?php echo htmlspecialchars($product['stars'] ?? 'Stars Not Available'); ?></p>
                <a href="add-to-cart.php?id=<?php echo $product['id']; ?>" class="btn btn-primary">Add to Cart</a>
            </div>
        </div>
    </div>
    <?php include('../includes/partials/footer.php'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
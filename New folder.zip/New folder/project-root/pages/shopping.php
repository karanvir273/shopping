<?php
session_start();
include '../includes/db.php'; // Ensure this file contains your database connection

// Get the database connection
$conn = getDB(); // Replace with the appropriate function or connection method

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Fetch products from the database
$query = "SELECT * FROM products";
$result = $conn->query($query);

// Get user's favorites
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

if ($user_id) {
    // Fetch favorites for logged-in user
    $favorites_query = $conn->prepare("SELECT product_id FROM favorites WHERE user_id = ?");
    $favorites_query->bind_param("i", $user_id);
    $favorites_query->execute();
    $favorites_result = $favorites_query->get_result();
    $favorites = [];
    while ($favorite = $favorites_result->fetch_assoc()) {
        $favorites[] = $favorite['product_id'];
    }
} else {
    // No favorites for not logged-in users
    $favorites = [];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Page</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .review-container {
            margin-bottom: 20px;
        }

        .review-item {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .review-item:last-child {
            border-bottom: none;
        }

        .review-form {
            margin-top: 20px;
        }

        .review-form .form-group {
            margin-bottom: 10px;
        }

        .rating-stars {
            color: gold;
            font-size: 1rem;
        }

        .favorite-button {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .favorite-button button {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .favorite {
            font-size: 14px !important;
            background: black !important;
            color: #fff !important;
        }

        .card-body {
            padding-top: 60px!important;
        }
    </style>


</head>

<body>
    <?php include '../includes/partials/header.php'; ?>
    <div class="container">
        <h1 class="mt-4">Shopping Page</h1>
        <div class="row">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card" id="product<?php echo $row['id']; ?>" style="position: relative;">
                        <div class="favorite-button">
                            <?php if (in_array($row['id'], $favorites)): ?>
                                <a href="toggle_favorite.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">Remove from Favorites</a>
                            <?php else: ?>
                                <a href="toggle_favorite.php?id=<?php echo $row['id']; ?>" class="btn favorite">Add to Favorites</a>
                            <?php endif; ?>
                        </div>




                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($row['description']); ?></p>
                            <p class="card-text"><strong>Price:</strong> $<?php echo number_format($row['price'], 2); ?></p>
                            <!-- Reviews Section -->
                            <div class="review-container">
                                <?php
                                // Fetch reviews for this product
                                $product_id = $row['id'];
                                $review_query = $conn->prepare("SELECT user_id, rating, comment, created_at FROM reviews WHERE product_id = ?");
                                $review_query->bind_param("i", $product_id);
                                $review_query->execute();
                                $reviews = $review_query->get_result();

                                if ($reviews->num_rows > 0) {
                                    while ($review = $reviews->fetch_assoc()):
                                ?>
                                        <div class="review-item">
                                            <p><strong><?php echo htmlspecialchars($review['user_id']); ?>:</strong></p>
                                            <p class="rating-stars">
                                                <?php
                                                // Display stars based on rating
                                                for ($i = 0; $i < $review['rating']; $i++) {
                                                    echo '★';
                                                }
                                                for ($i = $review['rating']; $i < 5; $i++) {
                                                    echo '☆';
                                                }
                                                ?>
                                            </p>
                                            <p><?php echo htmlspecialchars($review['comment']); ?></p>
                                            <p class="text-muted"><?php echo htmlspecialchars($review['created_at']); ?></p>
                                        </div>
                                <?php
                                    endwhile;
                                } else {
                                    echo '<p>No reviews yet.</p>';
                                }
                                ?>
                            </div>

                            <!-- Review Form -->
                            <div class="review-form">
                                <h5>Leave a Review</h5>
                                <form action="submit_review.php" method="post">
                                    <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                    <div class="form-group">
                                        <label for="username<?php echo $row['id']; ?>">Your Name</label>
                                        <input type="text" class="form-control" id="username<?php echo $row['id']; ?>" name="user_id" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="rating<?php echo $row['id']; ?>">Rating (1-5)</label>
                                        <input type="number" class="form-control" id="rating<?php echo $row['id']; ?>" name="rating" min="1" max="5" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="review<?php echo $row['id']; ?>">Your Review</label>
                                        <textarea class="form-control" id="review<?php echo $row['id']; ?>" name="comment" rows="3" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit Review</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    <?php include '../includes/partials/footer.php'; ?>
    <script>
        function toggleFavorite(productId) {
            // Redirect to the PHP script to handle the toggle
            window.location.href = 'toggle_favorite.php?id=' + productId;
        }
    </script>

</body>

</html>

<?php
$conn->close();
?>
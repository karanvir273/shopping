<?php
session_start();
include '../includes/db.php'; // Ensure this file contains your database connection

// Get the database connection
$conn = getDB(); // Replace with the appropriate function or connection method

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Get product ID and user ID from request
$product_id = intval($_GET['id']);
$user_id = 1; // Replace this with the actual user ID from session or authentication

// Check if the product is already in favorites
$check_query = $conn->prepare("SELECT * FROM favorites WHERE user_id = ? AND product_id = ?");
$check_query->bind_param("ii", $user_id, $product_id);
$check_query->execute();
$check_result = $check_query->get_result();

if ($check_result->num_rows > 0) {
    // Product is already in favorites, so remove it
    $delete_query = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND product_id = ?");
    $delete_query->bind_param("ii", $user_id, $product_id);
    $delete_query->execute();
    echo "Removed from favorites.";
} else {
    // Product is not in favorites, so add it
    $insert_query = $conn->prepare("INSERT INTO favorites (user_id, product_id) VALUES (?, ?)");
    $insert_query->bind_param("ii", $user_id, $product_id);
    $insert_query->execute();
    echo "Added to favorites.";
}

$check_query->close();
$insert_query->close();
$delete_query->close();
$conn->close();
?>

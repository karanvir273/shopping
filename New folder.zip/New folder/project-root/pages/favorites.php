<?php
session_start();
include '../includes/db.php'; // Ensure this file contains your database connection

// Get the database connection
$conn = getDB(); // Replace with the appropriate function or connection method

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // If user is not logged in, redirect to login page with a message
    header("Location: login.php?message=Please log in to view your favorites.");
    exit();
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Fetch favorite products from the database
$favorites_query = $conn->prepare("
    SELECT p.id, p.name, p.description, p.price
    FROM favorites f
    JOIN products p ON f.product_id = p.id
    WHERE f.user_id = ?
");
$favorites_query->bind_param("i", $user_id);
$favorites_query->execute();
$favorites_result = $favorites_query->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favorites Page</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../includes/partials/header.php'; ?>
<div class="container">
    <h1 class="mt-4">My Favorites</h1>
    <?php if ($favorites_result->num_rows > 0): ?>
    <div class="row">
        <?php while ($row = $favorites_result->fetch_assoc()): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($row['description']); ?></p>
                    <p class="card-text"><strong>Price:</strong> $<?php echo number_format($row['price'], 2); ?></p>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <p>No favorites found.</p>
    <?php endif; ?>
</div>
<?php include '../includes/partials/footer.php'; ?>
</body>
</html>

<?php
$favorites_query->close();
$conn->close();
?>

<?php
include('db.php');

function getRandomProducts($limit = 5) {
    $db = getDB();
    $sql = "SELECT * FROM products ORDER BY RAND() LIMIT ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param('i', $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getCategories() {
    $db = getDB();
    $sql = "SELECT DISTINCT genre FROM products";
    $result = $db->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Add more functions for handling user reviews, favorites, etc.
?>

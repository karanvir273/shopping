<?php
function getDB() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "digital_media_collection";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        return null; // Return null if the connection fails
    }
    return $conn; // Return the connection object if successful
}
?>
